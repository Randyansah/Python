Time and attendance tracking is one of any business’s most vital day-to-day operations. It may seem trivial, but managing hours is crucial for all members of an organization.

This program seeks to take attendance in instituitions without staff altering the date and time of arrival. 